'use strict';
const express = require('express');
const router = express.Router();

const {
  sequelize, Sequelize,
  OnboardingQuestion,
  OnboardingQuestionWeight,
  Category,
  UserOnboardingSubmission,
  UserQuestionnaireAnswer,
  UserPriority,
  User,
} = require('../models');

const { Op } = Sequelize;

/**
 * GET /onboarding/questions
 * - renvoie les questions FR actives, triées
 */
router.get('/questions', async (req, res) => {
  try {
    const lang = (req.query.lang || 'fr').toLowerCase();

    const questions = await OnboardingQuestion.findAll({
      where: { enabled: true, language: lang },
      order: [['sort_order', 'ASC'], ['id', 'ASC']],
      attributes: ['id', 'code', 'question', 'sort_order'],
    });

    res.json({
      language: lang,
      count: questions.length,
      items: questions,
    });
  } catch (e) {
    console.error('GET /onboarding/questions', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

/**
 * POST /onboarding/answers
 * Body attendu:
 * {
 *   user_id?: number,           // si tu n’as pas de middleware JWT
 *   language?: "fr",
 *   answers: [{question_id:number, value:1..5}, ...]  // >= 12 réponses conseillées
 * }
 * - crée une submission + enregistre les réponses
 * - calcule les scores par catégorie (valueCentered = value - 3) * weight
 * - normalise 0..100
 * - upsert user_priorities
 * - set users.onboarding_done = 1
 */
router.post('/answers', async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const lang = (req.body?.language || 'fr').toLowerCase();
    // user id: depuis le body, sinon depuis un éventuel middleware
    const userId = Number(req.body?.user_id || req.user?.id || 0);

    if (!userId) {
      await t.rollback();
      return res.status(400).json({ error: 'user_id requis (ou utilisez votre middleware auth)' });
    }

    const rawAnswers = Array.isArray(req.body?.answers) ? req.body.answers : [];
    // filtrage: question_id number, value 1..5
    const answers = rawAnswers
      .map(a => ({ qid: Number(a.question_id), val: Number(a.value) }))
      .filter(a => Number.isInteger(a.qid) && a.qid > 0 && a.val >= 1 && a.val <= 5);

    if (answers.length < 12) {
      await t.rollback();
      return res.status(400).json({ error: 'Au moins 12 réponses valides sont requises' });
    }

    // vérifier user existe
    const user = await User.findByPk(userId, { transaction: t, lock: t.LOCK.UPDATE });
    if (!user) {
      await t.rollback();
      return res.status(404).json({ error: 'Utilisateur introuvable' });
    }

    // ne garder que les questions actives / langue demandée
    const qids = [...new Set(answers.map(a => a.qid))];
    const validQuestions = await OnboardingQuestion.findAll({
      where: { id: qids, enabled: true, language: lang },
      attributes: ['id'],
      transaction: t,
    });
    const validSet = new Set(validQuestions.map(q => q.id));
    const filtered = answers.filter(a => validSet.has(a.qid));
    if (filtered.length < 12) {
      await t.rollback();
      return res.status(400).json({ error: 'Réponses insuffisantes sur questions actives' });
    }

    // créer la submission
    const submission = await UserOnboardingSubmission.create({
      user_id: userId,
      submitted_at: new Date(),
    }, { transaction: t });

    // enregistrer les réponses
    const toInsert = filtered.map(a => ({
      submission_id: submission.id,
      user_id: userId,
      question_id: a.qid,
      answer_value: a.val,
      createdAt: new Date(),
    }));
    await UserQuestionnaireAnswer.bulkCreate(toInsert, { transaction: t });

    // récupérer tous les poids pour ces questions
    const weights = await OnboardingQuestionWeight.findAll({
      where: { question_id: filtered.map(a => a.qid) },
      include: [{ model: Category, as: 'Category', attributes: ['id', 'name'] }],
      transaction: t,
    });

    // map rapide des réponses par question
    const ansMap = new Map(filtered.map(a => [a.qid, a.val]));

    // scores bruts par catégorie
    const scoreByCat = new Map();  // catId -> score
    for (const w of weights) {
      const qid = w.question_id;
      const val = ansMap.get(qid);
      if (typeof val !== 'number') continue;
      // centre la valeur: 1..5 -> -2..+2
      const centered = val - 3;
      const add = centered * Number(w.weight);
      const catId = Number(w.category_id);
      scoreByCat.set(catId, (scoreByCat.get(catId) || 0) + add);
    }

    // inclure toutes les catégories (valeur 0 par défaut) pour la normalisation
    const allCats = await Category.findAll({ attributes: ['id', 'name'], transaction: t });
    for (const c of allCats) {
      if (!scoreByCat.has(c.id)) scoreByCat.set(c.id, 0);
    }

    // normalisation 0..100
    const entries = [...scoreByCat.entries()]; // [ [catId, score], ... ]
    const rawScores = entries.map(([cid, s]) => s);
    const min = Math.min(...rawScores);
    const max = Math.max(...rawScores);

    const normalized = entries.map(([cid, s]) => {
      let score = 50.0;
      if (max !== min) score = ( (s - min) / (max - min) ) * 100.0;
      return { category_id: cid, score: Math.round(score * 10) / 10 }; // 1 décimale
    });

    // upsert user_priorities
    const now = new Date();
    // pour bulk upsert, on a besoin des champs
    const priorityRows = normalized.map(n => ({
      user_id: userId,
      category_id: n.category_id,
      score: n.score,
      createdAt: now,
      updatedAt: now,
    }));

    // MySQL: bulkCreate + updateOnDuplicate
    await UserPriority.bulkCreate(priorityRows, {
      updateOnDuplicate: ['score', 'updatedAt'],
      transaction: t,
    });

    // flag onboarding_done
    await user.update({ onboarding_done: true }, { transaction: t });

    // construire la réponse triée
    const withNames = await Promise.all(normalized.map(async n => {
      const cat = allCats.find(c => Number(c.id) === Number(n.category_id));
      return { category_id: n.category_id, category_name: cat?.name || '', score: n.score };
    }));
    withNames.sort((a, b) => b.score - a.score);
    withNames.forEach((row, idx) => { row.rank = idx + 1; });

    await t.commit();
    res.json({
      onboarding_done: true,
      user_id: userId,
      priorities: withNames,
    });
  } catch (e) {
    await t.rollback();
    console.error('POST /onboarding/answers', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
