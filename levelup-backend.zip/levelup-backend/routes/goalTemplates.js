'use strict';
const express = require('express');
const router = express.Router();
const { GoalTemplate, Category } = require('../models');

// GET /goal-templates?enabled=1&category_id=&q=
router.get('/', async (req, res) => {
  try {
    const where = {};
    if (req.query.enabled !== undefined) {
      const v = req.query.enabled;
      where.enabled = (v === '1' || v === 'true' || v === true);
    }
    if (req.query.category_id) where.category_id = Number(req.query.category_id);
    const q = (req.query.q || '').toString().trim();

    const rows = await GoalTemplate.findAll({
      where,
      include: [{ model: Category, as: 'Category' }],
      order: [['id', 'ASC']]
    });

    const filtered = q ? rows.filter(r => (r.title || '').toLowerCase().includes(q.toLowerCase())) : rows;
    res.json(filtered);
  } catch (e) {
    console.error('GET /goal-templates', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// GET /goal-templates/:id
router.get('/:id', async (req, res) => {
  try {
    const tpl = await GoalTemplate.findByPk(req.params.id, { include: [{ model: Category, as: 'Category' }] });
    if (!tpl) return res.status(404).json({ error: 'Template non trouvé' });
    res.json(tpl);
  } catch (e) {
    console.error('GET /goal-templates/:id', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// POST /goal-templates
router.post('/', async (req, res) => {
  try {
    const payload = req.body || {};
    if (!payload.title) return res.status(400).json({ error: 'title requis' });
    const tpl = await GoalTemplate.create(payload);
    res.status(201).json(tpl);
  } catch (e) {
    console.error('POST /goal-templates', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// PUT /goal-templates/:id/enabled { enabled: true|false }
router.put('/:id/enabled', async (req, res) => {
  try {
    const { enabled } = req.body || {};
    const tpl = await GoalTemplate.findByPk(req.params.id);
    if (!tpl) return res.status(404).json({ error: 'Template non trouvé' });
    tpl.enabled = !!enabled;
    await tpl.save();
    res.json({ id: tpl.id, enabled: tpl.enabled });
  } catch (e) {
    console.error('PUT /goal-templates/:id/enabled', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
