

import Navbar from '../components/Navbar';


function MyGoals() {
return (
    <div className="DashBoard"> 
        <Navbar></Navbar>       
    </div>
);
}
export default MyGoals;