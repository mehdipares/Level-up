// src/pages/Onboarding.jsx
import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { getCurrentUserId } from '../utils/auth';

function authHeaders(json = false) {
  const h = new Headers({ Accept: 'application/json' });
  const t = localStorage.getItem('token');
  if (t) h.set('Authorization', `Bearer ${t}`);
  if (json) h.set('Content-Type', 'application/json');
  return h;
}

function Likert({ value, onChange, name }) {
  // 1 = pas d’accord ··· 5 = tout à fait d’accord
  return (
    <div className="d-flex align-items-center gap-3 flex-wrap">
      {[1, 2, 3, 4, 5].map(v => (
        <label key={v} className="d-inline-flex align-items-center gap-2">
          <input
            type="radio"
            name={name}
            className="form-check-input"
            checked={value === v}
            onChange={() => onChange(v)}
          />
          <small className="text-muted fw-semibold">{v}</small>
        </label>
      ))}
    </div>
  );
}

export default function Onboarding() {
  const userId = useMemo(() => getCurrentUserId() ?? null, []);
  const [lang] = useState('fr');

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);
  const [questions, setQuestions] = useState([]);

  // index courant (0..N-1)
  const [idx, setIdx] = useState(0);
  // réponses collectées { [question_id]: 1..5 }
  const [answers, setAnswers] = useState({});
  // soumission & résultat
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);

  const fetchQuestions = async () => {
    setLoading(true); setErr(null);
    try {
      const res = await fetch(`/onboarding/questions?lang=${lang}`, { headers: authHeaders() });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      const items = Array.isArray(data.items) ? data.items : [];
      setQuestions(items);
      setIdx(0);
    } catch (e) {
      setErr(e.message || 'Erreur de chargement');
    } finally {
      setLoading(false);
    }
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { fetchQuestions(); }, [lang]);

  const total = questions.length;
  const current = questions[idx] || null;
  const answeredCount = Object.keys(answers).length;
  const percent = total ? Math.round(((idx + 1) / total) * 100) : 0;

  const setAnswer = (qid, v) => {
    setAnswers(prev => ({ ...prev, [qid]: v }));
  };

  const handleSubmit = async () => {
    const flat = Object.entries(answers)
      .map(([qid, val]) => ({ question_id: Number(qid), value: Number(val) }))
      .filter(a => a.question_id > 0 && a.value >= 1 && a.value <= 5);

    if (!userId) return alert('Connecte-toi pour valider le questionnaire.');
    if (flat.length < 12) return alert('Merci de répondre à au moins 12 questions.');

    setSubmitting(true); setErr(null);
    try {
      const res = await fetch('/onboarding/answers', {
        method: 'POST',
        headers: authHeaders(true),
        body: JSON.stringify({ user_id: Number(userId), language: lang, answers: flat })
      });
      if (!res.ok) throw new Error(await res.text());
      const payload = await res.json();
      setResult(payload);
    } catch (e) {
      setErr(e.message || 'Erreur lors de la soumission');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return (
    <div className="DashBoard">
      <Navbar />
      <div className="container py-4">
        <h2>Onboarding</h2>
        <div>Chargement des questions…</div>
      </div>
    </div>
  );

  if (result) {
    const list = Array.isArray(result.priorities) ? result.priorities : [];
    return (
      <div className="DashBoard">
        <Navbar />
        <div className="container py-4">
          <h2>Tes priorités 💡</h2>
          {err && <div className="alert alert-danger mt-2">{String(err)}</div>}
          <p className="text-muted">Catégorie #1 : +50% d’XP · Catégorie #2 : +25%.</p>

          <ul className="list-unstyled d-flex flex-column gap-2">
            {list.map(row => (
              <li key={row.category_id} className="p-3 border rounded bg-white">
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <strong>#{row.rank} — {row.category_name}</strong>
                  <small>{row.score}%</small>
                </div>
                <div className="progress" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                  <div className="progress-bar" style={{ width: `${Math.round(row.score)}%` }} />
                </div>
              </li>
            ))}
          </ul>

          <div className="mt-4 d-flex gap-2">
            {/* Utilise la même casse que dans App.js */}
            <Link className="btn btn-primary" to="/DashBoard">Aller au Dashboard</Link>
            <button className="btn btn-outline-secondary" onClick={() => setResult(null)}>Revoir mes réponses</button>
          </div>
        </div>
      </div>
    );
  }

  // Vue "1 question à la fois"
  return (
    <div className="DashBoard">
      <Navbar />
      <div className="container py-4">
        <h2>Onboarding</h2>
        {err && <div className="alert alert-danger mt-2">{String(err)}</div>}
        <p className="text-muted mb-3">
          Réponds sur une échelle de 1 (pas du tout) à 5 (tout à fait).
          Il faut répondre à <b>au moins 12</b> questions sur {total}.
        </p>

        {/* Progression */}
        <div className="d-flex align-items-center gap-3 mb-3">
          <div className="flex-grow-1">
            <div className="progress" role="progressbar" aria-valuemin="0" aria-valuemax="100">
              <div className="progress-bar" style={{ width: `${percent}%` }} />
            </div>
          </div>
          <small>Question {Math.min(idx + 1, total)} / {total} — {answeredCount}/{total} répondues</small>
        </div>

        {/* Question courante */}
        {current ? (
          <div className="p-4 border rounded bg-white">
            <div className="mb-3" style={{ fontWeight: 600 }}>
              {current.question}
            </div>
            <Likert
              name={`q-${current.id}`}
              value={answers[current.id] ?? 0}
              onChange={(v) => setAnswer(current.id, v)}
            />
          </div>
        ) : (
          <div className="alert alert-warning">Aucune question active pour le moment.</div>
        )}

        {/* Actions */}
        <div className="d-flex justify-content-between mt-3">
          <button
            className="btn btn-outline-secondary"
            disabled={idx === 0}
            onClick={() => setIdx(i => Math.max(0, i - 1))}
          >
            ← Précédent
          </button>

          {idx < total - 1 ? (
            <div className="d-flex gap-2">
              <button className="btn btn-outline-secondary" onClick={() => setIdx(i => Math.min(total - 1, i + 1))}>
                Passer →
              </button>
              <button
                className="btn btn-primary"
                onClick={() => setIdx(i => Math.min(total - 1, i + 1))}
                disabled={(answers[current?.id] ?? 0) === 0}
                title={(answers[current?.id] ?? 0) === 0 ? 'Choisis une réponse pour continuer' : ''}
              >
                Suivant →
              </button>
            </div>
          ) : (
            <button
              className="btn btn-success"
              disabled={submitting || answeredCount < 12}
              onClick={handleSubmit}
              title={answeredCount < 12 ? 'Réponds à au moins 12 questions' : 'Envoyer mes réponses'}
            >
              {submitting ? 'Envoi…' : 'Valider mes réponses'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
