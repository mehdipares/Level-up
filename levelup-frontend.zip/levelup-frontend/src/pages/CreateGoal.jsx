

import Navbar from '../components/Navbar';


function CreateGoal() {
return (
    <div className="DashBoard"> 
        <Navbar></Navbar>       
    </div>
);
}
export default CreateGoal;