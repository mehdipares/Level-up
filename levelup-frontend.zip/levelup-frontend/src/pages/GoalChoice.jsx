// src/pages/GoalChoice.jsx
import { useEffect, useMemo, useState } from 'react';
import Navbar from '../components/Navbar';
import { getCurrentUserId } from '../utils/auth';

export default function GoalChoice() {
  const userId = useMemo(() => getCurrentUserId() ?? null, []);
  const [items, setItems] = useState([]);
  const [q, setQ] = useState('');
  const [cadence, setCadence] = useState('daily');
  const [catMap, setCatMap] = useState({});
  const [filter, setFilter] = useState('tous');
  const [busy, setBusy] = useState(null);
  const [err, setErr] = useState(null);

  // ----- Espace Gestion -----
  const [manageStatus, setManageStatus] = useState('all'); // all | active | archived
  const [goals, setGoals] = useState([]);
  const [mgmtBusy, setMgmtBusy] = useState(null);
  const [cadenceEdit, setCadenceEdit] = useState({});     // { [user_goal_id]: 'daily'|'weekly' }

  const fetchJSON = async (url, init) => {
    const h = new Headers(init?.headers || {});
    h.set('Accept', 'application/json');
    const t = localStorage.getItem('token');
    if (t) h.set('Authorization', `Bearer ${t}`);
    if (init?.body && !h.has('Content-Type')) h.set('Content-Type', 'application/json');
    const res = await fetch(url, { ...init, headers: h });
    if (!res.ok) {
      let message = `HTTP ${res.status}`;
      try { message = (await res.json())?.error || (await res.text()) || message; } catch {}
      throw new Error(message);
    }
    try { return await res.json(); } catch { return null; }
  };

  const loadCategories = async () => {
    try {
      const arr = await fetchJSON('/categories', { cache: 'no-store' });
      const map = {};
      (Array.isArray(arr) ? arr : []).forEach(c => { map[(c.name || '').toLowerCase()] = c.id; });
      setCatMap(map);
    } catch { /* ignore */ }
  };

  const loadTemplates = async () => {
    const params = new URLSearchParams();
    params.set('enabled', '1');
    if (q) params.set('q', q);
    try {
      const arr = await fetchJSON(`/goal-templates?${params.toString()}`, { cache: 'no-store' });
      setItems(Array.isArray(arr) ? arr : (arr?.rows || arr?.data || []));
      setErr(null);
    } catch (e) {
      setErr(e.message || 'Erreur chargement');
    }
  };

  const loadUserGoals = async (status = manageStatus) => {
    if (!userId) return;
    try {
      const arr = await fetchJSON(`/users/${userId}/user-goals?status=${status}`, { cache: 'no-store' });
      const rows = Array.isArray(arr) ? arr : (arr?.rows || arr?.data || []);
      setGoals(rows);
      const map = {};
      rows.forEach(g => {
        map[g.id] = g.cadence || (g.effective_frequency_type === 'weekly' ? 'weekly' : 'daily');
      });
      setCadenceEdit(map);
    } catch (e) {
      console.error('loadUserGoals', e);
    }
  };

  useEffect(() => { loadCategories(); loadTemplates(); loadUserGoals('all'); /* eslint-disable-next-line */ }, []);

  const addToUser = async (tplId) => {
    if (!userId) return alert('Connecte-toi');
    setBusy(tplId);
    try {
      await fetchJSON(`/users/${userId}/user-goals`, {
        method: 'POST',
        body: JSON.stringify({ template_id: Number(tplId), cadence })
      });
      alert('Ajouté à tes objectifs ✅');
      setErr(null);
      await loadUserGoals(manageStatus);
    } catch (e) {
      alert(e.message);
    } finally {
      setBusy(null);
    }
  };

  const byCategory = (g) => {
    if (filter === 'tous') return true;
    const wantedId = catMap[filter];
    if (wantedId && g.category_id) return Number(g.category_id) === Number(wantedId);
    const catText = ((g.category?.name || g.category || g.type || '') + '').toLowerCase();
    return catText.includes(filter);
  };

  // ----- Espace Gestion actions -----
  const archiveUG = async (ugid) => {
    setMgmtBusy(ugid);
    try {
      await fetchJSON(`/users/${userId}/user-goals/${ugid}/archive`, { method: 'PATCH' });
      await loadUserGoals(manageStatus);
    } catch (e) { alert(e.message); }
    finally { setMgmtBusy(null); }
  };

  // Réactivation DÉDIÉE (ne change PAS la cadence)
  const unarchiveUG = async (ugid) => {
    setMgmtBusy(`unarch-${ugid}`);
    try {
      await fetchJSON(`/users/${userId}/user-goals/${ugid}/unarchive`, { method: 'PATCH' });
      await loadUserGoals(manageStatus);
    } catch (e) { alert(e.message); }
    finally { setMgmtBusy(null); }
  };

  // Suppression définitive d’un objectif archivé
  const deleteUG = async (ugid) => {
    if (!window.confirm('Supprimer définitivement cet objectif archivé ? Cette action est irréversible.')) return;
    setMgmtBusy(`del-${ugid}`);
    try {
      await fetchJSON(`/users/${userId}/user-goals/${ugid}`, { method: 'DELETE' });
      await loadUserGoals(manageStatus);
    } catch (e) { alert(e.message); }
    finally { setMgmtBusy(null); }
  };

  // Changer la cadence (actif uniquement) — sécurise la valeur envoyée
  const applyCadence = async (ugid, cadenceValue) => {
    setMgmtBusy(`sched-${ugid}`);
    try {
      const normalized = (cadenceValue === 'weekly') ? 'weekly' : 'daily';
      await fetchJSON(`/users/${userId}/user-goals/${ugid}/schedule`, {
        method: 'PATCH',
        body: JSON.stringify({ cadence: normalized })
      });
      await loadUserGoals(manageStatus);
      alert('Cadence mise à jour ✅');
    } catch (e) { alert(e.message); }
    finally { setMgmtBusy(null); }
  };

  return (
    <div className="DashBoard">
      <Navbar />
      <div className="container py-3">

        {/* --------- CATALOGUE --------- */}
        <h2>Catalogue d’objectifs</h2>

        <div className="d-flex gap-2 my-2">
          <input className="form-control" placeholder="Rechercher..." value={q} onChange={e => setQ(e.target.value)} />
          <button className="btn btn-outline-primary" onClick={loadTemplates}>Rechercher</button>
          <select className="form-select" value={filter} onChange={e => setFilter(e.target.value)}>
            <option value="tous">tous</option>
            <option value="sport">sport</option>
            <option value="freelance">freelance</option>
            <option value="mindset">mindset</option>
          </select>
          <select className="form-select" value={cadence} onChange={e => setCadence(e.target.value)}>
            <option value="daily">Quotidien</option>
            <option value="weekly">1× / semaine</option>
          </select>
        </div>

        {err && <div className="text-danger">{err}</div>}

        <ul className="list-unstyled d-flex flex-column gap-2 mb-4">
          {items.filter(byCategory).map(t => (
            <li key={t.id}>
              <div className="d-flex align-items-center justify-content-between rounded px-3 py-2 border bg-white">
                <div>
                  <div style={{ fontWeight: 600 }}>{t.title}</div>
                  <small className="text-muted">{t.description}</small><br />
                  <small className="text-muted">XP de base : {t.base_xp}</small>
                </div>
                <button
                  className="btn btn-primary"
                  disabled={busy === t.id}
                  onClick={() => addToUser(t.id)}
                >
                  {busy === t.id ? 'Ajout…' : 'Ajouter'}
                </button>
              </div>
            </li>
          ))}
        </ul>

        {/* --------- ESPACE GESTION --------- */}
        <div className="d-flex align-items-center justify-content-between">
          <h3 className="mb-2">Mes objectifs — Espace Gestion</h3>
          <div className="d-flex gap-2">
            <select
              className="form-select"
              value={manageStatus}
              onChange={async (e) => { setManageStatus(e.target.value); await loadUserGoals(e.target.value); }}
            >
              <option value="all">Tous</option>
              <option value="active">Actifs</option>
              <option value="archived">Archivés</option>
            </select>
            <button className="btn btn-outline-secondary" onClick={() => loadUserGoals(manageStatus)}>Rafraîchir</button>
          </div>
        </div>

        {!goals.length && <div className="text-muted">Aucun objectif à afficher.</div>}

        <ul className="list-unstyled d-flex flex-column gap-2">
          {goals.map(g => {
            const isArchived = g.status === 'archived';
            const selected = cadenceEdit[g.id] ?? g.cadence ?? (g.effective_frequency_type === 'weekly' ? 'weekly' : 'daily');
            const originalCadence = g.cadence ?? (g.effective_frequency_type === 'weekly' ? 'weekly' : 'daily');

            const disabledSelect =
              isArchived ||
              mgmtBusy === g.id ||
              mgmtBusy === `sched-${g.id}` ||
              mgmtBusy === `unarch-${g.id}` ||
              mgmtBusy === `del-${g.id}`;

            return (
              <li key={g.id}>
                <div className="d-flex align-items-center justify-content-between rounded px-3 py-2 border bg-white">
                  <div>
                    <div style={{ fontWeight: 600 }}>
                      {g.title}{' '}
                      <span className={`badge ms-1 ${isArchived ? 'bg-secondary' : (selected === 'weekly' ? 'bg-info' : 'bg-success')}`}>
                        {isArchived ? 'archived' : selected}
                      </span>
                    </div>
                    <small className="text-muted">
                      Fenêtre:&nbsp;
                      {new Date(g.period_start).toLocaleString()} → {new Date(g.period_end).toLocaleString()}
                      {g.last_completed_at && <> · Dernière: {new Date(g.last_completed_at).toLocaleString()}</>}
                    </small>
                  </div>

                  <div className="d-flex align-items-center gap-2">
                    <select
                      className="form-select"
                      value={selected}
                      onChange={e =>
                        setCadenceEdit(prev => ({
                          ...prev,
                          [g.id]: (e.target.value === 'weekly' ? 'weekly' : 'daily')
                        }))
                      }
                      disabled={disabledSelect}
                      style={{ minWidth: 160 }}
                    >
                      <option value="daily">Quotidien</option>
                      <option value="weekly">1× / semaine</option>
                    </select>

                    {/* Appliquer cadence (actif uniquement) */}
                    {!isArchived && (
                      <button
                        className="btn btn-outline-primary btn-sm"
                        disabled={(selected === originalCadence) || mgmtBusy === `sched-${g.id}`}
                        onClick={() => applyCadence(g.id, selected)} // g.id = user_goal_id
                        title="Changer la cadence (effet sur la période courante et futures)"
                      >
                        {mgmtBusy === `sched-${g.id}` ? '...' : 'Appliquer cadence'}
                      </button>
                    )}

                    {/* Archiver / Réactiver / Supprimer (archivé uniquement) */}
                    {!isArchived ? (
                      <button
                        className="btn btn-outline-danger btn-sm"
                        disabled={mgmtBusy === g.id}
                        onClick={() => archiveUG(g.id)}
                        title="Archiver (conserve l'historique)"
                      >
                        {mgmtBusy === g.id ? '...' : 'Archiver'}
                      </button>
                    ) : (
                      <>
                        <button
                          className="btn btn-outline-success btn-sm"
                          disabled={mgmtBusy === `unarch-${g.id}` || mgmtBusy === `del-${g.id}`}
                          onClick={() => unarchiveUG(g.id)}
                          title="Réactiver (cadence inchangée)"
                        >
                          {mgmtBusy === `unarch-${g.id}` ? '...' : 'Réactiver'}
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          disabled={mgmtBusy === `del-${g.id}` || mgmtBusy === `unarch-${g.id}`}
                          onClick={() => deleteUG(g.id)}
                          title="Supprimer définitivement (archivé uniquement)"
                        >
                          {mgmtBusy === `del-${g.id}` ? '...' : 'Supprimer'}
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>

      </div>
    </div>
  );
}
