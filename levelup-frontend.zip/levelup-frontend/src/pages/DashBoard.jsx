// src/pages/DashBoard.jsx
import XPBar from '../components/XPBar';
import Navbar from '../components/Navbar';
import QuoteOfTheDay from '../components/QuoteOfTheDay';
import UserGoals from '../components/UserGoals';
import DashboardStats from '../components/DashboardStats';

export default function DashBoard() {
  return (
    <div className="DashBoard">
      <Navbar />

      <div className="container py-3">
        {/* XPBar récupère /users/:id/xp automatiquement */}
        <XPBar />
        {/* Citation motivante */}
        <QuoteOfTheDay />
        {/* Objectifs actifs (user_goals) */}
        <UserGoals className="mt-3" />
      </div>

      <div className="mt-3">
        <DashboardStats />
      </div>
    </div>
  );
}
