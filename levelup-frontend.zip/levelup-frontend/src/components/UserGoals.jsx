// src/components/UserGoals.jsx
import { useEffect, useMemo, useState } from 'react';
import { getCurrentUserId } from '../utils/auth';

function authHeaders() {
  const h = new Headers({ 'Accept': 'application/json', 'Content-Type': 'application/json' });
  const t = localStorage.getItem('token');
  if (t) h.set('Authorization', `Bearer ${t}`);
  return h;
}

export default function UserGoals({ userId: userIdProp, className = '' }) {
  const userId = useMemo(() => userIdProp ?? getCurrentUserId() ?? null, [userIdProp]);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(null);
  const [err, setErr] = useState(null);

  const load = async () => {
    if (!userId) { setErr('Utilisateur non identifié'); setLoading(false); return; }
    setLoading(true); setErr(null);
    try {
      const res = await fetch(`/users/${userId}/user-goals`, { headers: authHeaders(), cache: 'no-store' });
      if (!res.ok) throw new Error(await res.text());
      const arr = await res.json();
      setRows(Array.isArray(arr) ? arr : (arr.rows || arr.data || []));
    } catch (e) {
      setErr(e.message || 'Erreur de chargement');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [userId]);

  const complete = async (ugid) => {
    setBusy(ugid);
    try {
      const res = await fetch(`/users/${userId}/user-goals/${ugid}/complete`, { method: 'PATCH', headers: authHeaders() });
      if (!res.ok) throw new Error(await res.text());
      await load();
      // rafraîchir la barre d’XP si tu l’utilises :
      window.dispatchEvent(new Event('xp:changed'));
    } catch (e) {
      const msg = String(e.message || '');
      if (msg.includes('Déjà complété')) alert('Déjà complété pour la période en cours.');
      else alert(msg);
    } finally {
      setBusy(null);
    }
  };

  // Dashboard = lecture + action → on permet d’archiver ici, mais PAS de changer la cadence
  const archiveUG = async (ugid) => {
    setBusy(`arch-${ugid}`);
    try {
      const res = await fetch(`/users/${userId}/user-goals/${ugid}/archive`, { method: 'PATCH', headers: authHeaders() });
      if (!res.ok) throw new Error(await res.text());
      await load();
    } catch (e) {
      alert(e.message || 'Erreur');
    } finally {
      setBusy(null);
    }
  };

  if (loading) return <div className={className}>Chargement…</div>;
  if (err)      return <div className={className} style={{ color: 'red' }}>{err}</div>;
  if (!rows.length) return <div className={className}>Aucun objectif actif. Va dans le catalogue pour en ajouter.</div>;

  return (
    <div className={className}>
      <ul className="list-unstyled d-flex flex-column gap-2">
        {rows.map(g => {
          const can = !!g.can_complete;
          const cadence = g.cadence || (g.effective_frequency_type === 'weekly' ? 'weekly' : 'daily');
          const archBusy = busy === `arch-${g.id}`;
          const compBusy = busy === g.id;
          return (
            <li key={g.id}>
              <div
                className="d-flex align-items-center justify-content-between rounded px-3 py-2 border bg-white"
                style={{ boxShadow: '0 1px 6px rgba(0,0,0,.06)' }}
              >
                <div className="d-flex flex-column">
                  <div>
                    <strong>{g.title}</strong>{' '}
                    <span className={`badge ${cadence === 'weekly' ? 'bg-info' : 'bg-success'}`}>
                      {cadence}
                    </span>
                  </div>
                  <small className="text-muted">
                    Fenêtre:&nbsp;
                    {new Date(g.period_start).toLocaleString()} → {new Date(g.period_end).toLocaleString()}
                    {g.last_completed_at && <> · Dernière: {new Date(g.last_completed_at).toLocaleString()}</>}
                  </small>
                </div>

                <div className="d-flex align-items-center gap-2">
                  <button
                    className={`btn btn-sm ${can ? 'btn-primary' : 'btn-secondary'}`}
                    disabled={!can || compBusy || archBusy}
                    onClick={() => complete(g.id)}
                    title={can ? 'Valider maintenant' : 'Déjà complété pour la période'}
                  >
                    {compBusy ? '...' : (can ? 'Valider' : 'Déjà fait')}
                  </button>

                  <button
                    className="btn btn-outline-danger btn-sm"
                    disabled={archBusy || compBusy}
                    onClick={() => archiveUG(g.id)}
                    title="Archiver cet objectif (historique conservé)"
                  >
                    {archBusy ? '...' : 'Archiver'}
                  </button>
                </div>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
