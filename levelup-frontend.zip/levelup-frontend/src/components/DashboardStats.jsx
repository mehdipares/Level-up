import { useEffect, useMemo, useState } from 'react';

/* -------- utils: récupérer l'id côté front (localStorage/JWT) -------- */
function base64UrlDecode(s){try{const pad='='.repeat((4-(s.length%4))%4);return atob((s+pad).replace(/-/g,'+').replace(/_/g,'/'))}catch{return''}}
function decodeJWT(t){try{if(!t) return null; const p=t.split('.')[1]; return JSON.parse(base64UrlDecode(p));}catch{return null}}
function getCurrentUserId(){
  try{const u=JSON.parse(localStorage.getItem('user')||'null'); if(u?.id) return u.id;}catch{}
  const payload = decodeJWT(localStorage.getItem('token'));
  return payload?.id ?? payload?.userId ?? payload?.sub ?? null;
}
/* -------------------------------------------------------------------- */

export default function DashboardStats({ userId: userIdProp, className = '' }) {
  const userId = useMemo(() => userIdProp ?? getCurrentUserId() ?? null, [userIdProp]);

  const [state, setState] = useState({
    loading: true,
    error: null,
    level: 0,
    goalsTotal: 0,
    goalsDone: 0,
    activeDays: 0,
  });

  const fetchJSON = async (url) => {
    const headers = new Headers();
    headers.set('Accept', 'application/json');
    const token = localStorage.getItem('token');
    if (token) headers.set('Authorization', `Bearer ${token}`);

    const res = await fetch(url, { cache: 'no-store', headers });
    const ct  = res.headers.get('content-type') || '';
    if (!res.ok) throw new Error(await res.text());
    if (!ct.includes('application/json')) throw new Error(`Réponse non JSON (${ct})`);
    return res.json();
  };

  const load = async () => {
    if (!userId) { setState(s => ({ ...s, loading: false, error: 'Utilisateur non identifié' })); return; }
    try {
      setState(s => ({ ...s, loading: true, error: null }));

      // 1) Niveau
      const xpData = await fetchJSON(`/users/${userId}/xp`); // { level, ... }

      // 2) Objectifs actifs via user_goals
      const ugData = await fetchJSON(`/users/${userId}/user-goals?active=1`);
      const list = Array.isArray(ugData) ? ugData : (ugData.rows || ugData.data || []);

      // Normalisation minimale
      const goals = list.map(ug => ({
        id: ug.id,
        completed: !!(ug.completed),
        completed_at: ug.completed_at || ug.completedAt || null,
        updatedAt: ug.updatedAt || ug.updated_at || null,
        createdAt: ug.createdAt || ug.created_at || null,
      }));

      const goalsTotal = goals.length;
      const goalsDone  = goals.filter(g => g.completed).length;

      // Jours actifs = nb de dates distinctes où un objectif est complété
      const daysSet = new Set(
        goals
          .filter(g => g.completed)
          .map(g => {
            const d = g.completed_at || g.updatedAt || g.createdAt;
            const date = d ? new Date(d) : null;
            if (!date || isNaN(date)) return null;
            return date.toISOString().slice(0,10); // YYYY-MM-DD
          })
          .filter(Boolean)
      );
      const activeDays = daysSet.size;

      setState({
        loading: false,
        error: null,
        level: xpData.level ?? 0,
        goalsTotal,
        goalsDone,
        activeDays,
      });
    } catch (e) {
      setState(s => ({ ...s, loading: false, error: e.message || 'Erreur de chargement' }));
    }
  };

  useEffect(() => {
    let alive = true;
    (async () => { if (alive) await load(); })();

    // se met à jour après validation d’objectifs
    const onChanged = () => { if (alive) load(); };
    window.addEventListener('xp:changed', onChanged);
    window.addEventListener('goals:changed', onChanged);
    return () => { alive = false; window.removeEventListener('xp:changed', onChanged); window.removeEventListener('goals:changed', onChanged); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  if (state.loading) return null;
  if (state.error)   return <div className="text-danger">Stats : {state.error}</div>;

  const { level, goalsTotal, goalsDone, activeDays } = state;
  const percent = goalsTotal ? Math.round((goalsDone / goalsTotal) * 100) : 0;

  return (
    <div
      className={className}
      style={{
        background: '#efe9ff', borderRadius: 16, padding: 16,
        boxShadow: '0 4px 18px rgba(69,100,255,0.10)'
      }}
    >
      {/* Ligne 1 : badge niveau (grand) */}
      <div className="d-flex justify-content-center mb-2">
        <div
          className="d-inline-flex align-items-center justify-content-center"
          style={{
            minWidth: 120, height: 44, borderRadius: 999,
            background: '#ffffffaa', border: '1px solid #d9d9ff',
            fontWeight: 700, fontSize: 18
          }}
          aria-label={`Niveau ${level}`}
          title={`Niveau ${level}`}
        >
          Niveau&nbsp;{level}
        </div>
      </div>

      {/* Ligne 2 : objectifs (barre arrondie) */}
      <div className="mb-2 text-center" style={{ fontWeight: 600, color: '#444' }}>
        Objectifs :
      </div>
      <div className="progress goals-progress mx-auto mb-3" style={{ height: 14, borderRadius: 999, maxWidth: 360, background: '#9db4ff' }} aria-label="Progression des objectifs">
        <div
          className="progress-bar"
          role="progressbar"
          style={{ width: `${percent}%`, background: '#f2c200', borderRadius: 999 }}
          aria-valuenow={percent}
          aria-valuemin="0"
          aria-valuemax="100"
          title={`${goalsDone}/${goalsTotal} (${percent}%)`}
        />
      </div>

      {/* Ligne 3 : jours actifs */}
      <div className="text-center" style={{ color: '#333', fontWeight: 600, marginBottom: 2 }}>
        Jours actifs :
      </div>
      <div className="text-center" style={{ color: '#22c55e', fontSize: 36, fontWeight: 800, lineHeight: 1 }}>
        {activeDays}
      </div>
    </div>
  );
}
